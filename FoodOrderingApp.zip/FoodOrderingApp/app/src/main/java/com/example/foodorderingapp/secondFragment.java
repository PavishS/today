package com.example.foodorderingapp;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class secondFragment extends Fragment {
    ListView lvSelected;
    ArrayList<String> listItems = new ArrayList<String>();
    HashMap<String, Integer> cost = new HashMap<String,Integer>();
    CustomAdapter adapter;
    Button Confirm;
    private secondFragmentListener listener;
    public interface secondFragmentListener{
        void onInputBSent();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_second, container, false);

        lvSelected=v.findViewById(R.id.menuSelected);
        Confirm=v.findViewById(R.id.confirm);
        adapter= new CustomAdapter(getActivity(),listItems);
        lvSelected.setAdapter(adapter);

        SharedPreferences sp = getContext().getSharedPreferences("BillDetail", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        cost.put("Pizza",150);
        cost.put("Burger",120);
        cost.put("Fries",60);
        cost.put("Spaghetti",150);
        cost.put("Soup",30);
        cost.put("Ice Cream",40);
        cost.put("Cola",30);

        Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putInt("total",0).commit();
                int total=0;
                Map<String,?> keys = sp.getAll();
                for(Map.Entry<String,?> entry : keys.entrySet()) {
                    if (Integer.parseInt(entry.getValue().toString()) > 0) {
                        int qty = (int) entry.getValue();
                        int cpi= cost.get(entry.getKey());
                        total=total+(cpi*qty);
                    }
                }
                editor.putInt("total",total).commit();
                listener.onInputBSent();
            }
        });
        return v;
    }
    public void addItems(String input) {
        if (!listItems.contains(input))
        {
            listItems.add(input);
            adapter.updateItems(listItems);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof secondFragmentListener){
            listener=(secondFragmentListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener=null;
    }
}