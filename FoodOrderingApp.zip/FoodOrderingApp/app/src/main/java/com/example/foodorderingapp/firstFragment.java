package com.example.foodorderingapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class firstFragment extends Fragment {
    private firstFragmentListener listener;
    ListView lv;
    public interface firstFragmentListener{
        void onInputASent(String input);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_first, container, false);
        ArrayList<String> menu= new ArrayList<>();
        menu.add("Pizza         - Rs 150");
        menu.add("Burger        - Rs 120");
        menu.add("Fries         - Rs 60");
        menu.add("Spaghetti     - Rs 150");
        menu.add("Soup          - Rs 30");
        menu.add("Ice Cream     - Rs 40");
        menu.add("Cola          - Rs 30");

        SharedPreferences sharedPrefs = getContext().getSharedPreferences("BillDetail", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();

        for(String i:menu){
            String[] arr=i.split("-");
            editor.putInt(arr[0].trim(),0);
            editor.commit();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1,menu);
        lv=v.findViewById(R.id.menu);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String itemValue=(String) lv.getItemAtPosition(i);
                String[] arr=itemValue.split("-");
                listener.onInputASent(arr[0].trim());
            }
        });
        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof firstFragmentListener)
        {
            listener=(firstFragmentListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener=null;
    }
}