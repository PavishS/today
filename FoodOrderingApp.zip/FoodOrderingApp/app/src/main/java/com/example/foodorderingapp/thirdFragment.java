package com.example.foodorderingapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class thirdFragment extends Fragment {
    TextView total;
    Button sms,pay,contact,locate;
    SharedPreferences sp,logged;
    String name,mobile;
    private static final int SEND_SMS_REQ=1;
    private static final int REQUEST_CALL=2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v= inflater.inflate(R.layout.fragment_third, container, false);
        sp = getContext().getSharedPreferences("BillDetail", Context.MODE_PRIVATE);
        logged=getContext().getSharedPreferences("Logged", Context.MODE_PRIVATE);

        total=v.findViewById(R.id.totalBill);
        sms=v.findViewById(R.id.SMS);
        pay=v.findViewById(R.id.Pay);
        contact=v.findViewById(R.id.contact);
        locate=v.findViewById(R.id.locate);



        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkPermission(Manifest.permission.SEND_SMS)){
                    sms.setEnabled(true);
                }
                else{
                    ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.SEND_SMS},SEND_SMS_REQ);
                }
                onSend(view);
            }
        });

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url=total.getText().toString().trim();
                url=url.replaceAll("[^\\d.]", "");
                if (!url.isEmpty()){
                goToUrl("http://www.payxyz.com/totbill="+url);
                }else{
                    Toast.makeText(getContext(), "Select Items", Toast.LENGTH_SHORT).show();
                }
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(getContext(),Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(getActivity(),new String[] {Manifest.permission.CALL_PHONE},REQUEST_CALL);
                }
                else{
                    Intent intent=new Intent(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:123456789"));
                    startActivity(intent);
                }

            }
        });

        locate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUri = Uri.parse("geo:10.902730572256342, 76.90055101348587");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        return v;
    }

    public void setTotal(){
        int val=sp.getInt("total",0);
        if (val>0){
            total.setText("TOTAL : Rs "+Integer.toString(val));
        }
        else{
            total.setText("TOTAL");
        }
    }
    public boolean checkPermission(String permission){
        int check= ContextCompat.checkSelfPermission(getContext(),permission);
        return (check== PackageManager.PERMISSION_GRANTED);
    }
    public void onSend(View v){
        name=logged.getString("name","");
        mobile=logged.getString("mobile","");

        if(checkPermission(Manifest.permission.SEND_SMS)){
            SmsManager smsMan=SmsManager.getDefault();
            if (!total.getText().toString().equals("TOTAL"))
            {
            smsMan.sendTextMessage(mobile,null,total.getText().toString(),null,null);
            Toast.makeText(getContext(), "Message Sent", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getContext(), "Select Items", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(getContext(), "Permission Failed", Toast.LENGTH_SHORT).show();
        }
    }
    public void goToUrl(String s){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(s));
        startActivity(i);
    }

}