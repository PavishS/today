package com.example.foodorderingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class SecondActivity extends AppCompatActivity implements firstFragment.firstFragmentListener,secondFragment.secondFragmentListener {
    firstFragment frag1;
    secondFragment frag2;
    thirdFragment frag3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        frag1 = new firstFragment();
        frag2= new secondFragment();
        frag3= new thirdFragment();
        FragmentManager fragMan=getSupportFragmentManager();
        FragmentTransaction fragTrans=fragMan.beginTransaction();
        fragTrans.replace(R.id.fragFirst,frag1);
        fragTrans.replace(R.id.fragSecond,frag2);
        fragTrans.replace(R.id.fragThird,frag3);
        fragTrans.commit();


    }

    @Override
    public void onInputASent(String input) {
        frag2.addItems(input);
    }

    @Override
    public void onInputBSent() {
        frag3.setTotal();
    }
}