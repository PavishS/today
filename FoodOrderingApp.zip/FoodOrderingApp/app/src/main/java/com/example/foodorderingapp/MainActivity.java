package com.example.foodorderingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,pass;
    Button login;
    SharedPreferences sp,logged;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.nameET);
        pass=findViewById(R.id.passwordET);
        login=findViewById(R.id.Login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,SecondActivity.class);
                sp=getSharedPreferences("Login", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sp.edit();
                if (validateUsername()&&validatePassword())
                {
                    logged=getSharedPreferences("Logged",Context.MODE_PRIVATE);
                    SharedPreferences.Editor loggedEditor= logged.edit();
                    String nameTxt=name.getText().toString().trim();
                    String passTxt=pass.getText().toString().trim();
                    loggedEditor.putString("mobile",sp.getString(nameTxt+passTxt+"Mob",""));
                    loggedEditor.putString("name",nameTxt);
                    loggedEditor.commit();
                    startActivity(i);
                }
            }
        });
    }

    private boolean validatePassword(){
        String nameTxt=name.getText().toString().trim();
        String passTxt=pass.getText().toString().trim();
        if (passTxt.isEmpty()){
            pass.setError("Empty");
            return false;
        }
        else if(!passTxt.equals(sp.getString(nameTxt,""))){
            pass.setError("Wrong Password");
            return false;
        }
        else{
            pass.setError(null);
            return true;
        }

    }
    private boolean validateUsername() {
        String usernameInput = name.getText().toString().trim();
        if (usernameInput.isEmpty()) {
            name.setError("Field can't be empty");
            return false;
        } else if (usernameInput.length() > 15) {
            name.setError("Username too long");
            return false;
        } else if (!sp.contains(usernameInput)){
            name.setError("UserName not found");
            return false;
        }
        else {
            name.setError(null);
            return true;
        }
    }
}