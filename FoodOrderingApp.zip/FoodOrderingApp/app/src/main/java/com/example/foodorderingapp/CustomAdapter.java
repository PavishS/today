package com.example.foodorderingapp;

import android.app.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<String> {

    private  Activity context;
    private  ArrayList<String> maintitle;

    public CustomAdapter(Activity context, ArrayList<String> maintitle) {
        super(context, R.layout.item, maintitle);
        this.context=context;
        this.maintitle=maintitle;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.item, null,true);
        Button increment = rowView.findViewById(R.id.increment);
        Button decrement=rowView.findViewById(R.id.decrement);
        TextView value=rowView.findViewById(R.id.value);
        TextView titleText = (TextView) rowView.findViewById(R.id.expandedListItem);
        SharedPreferences sharedPrefs = context.getSharedPreferences("BillDetail", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();

        titleText.setText(maintitle.get(position)+"             = ");
        String base=(String) maintitle.get(position);
        int val=sharedPrefs.getInt(base,0);
        value.setText(Integer.toString(val));
        increment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String base=(String) maintitle.get(position);
                int val=sharedPrefs.getInt(base,0);
                value.setText(Integer.toString(val+1));
                editor.putInt(base,val+1);
                editor.commit();
            }
        });

        decrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String base=(String) maintitle.get(position);
                int val=sharedPrefs.getInt(base,0);
                if (val>0){
                value.setText(Integer.toString(val-1));
                editor.putInt(base,val-1);
                editor.commit();
                }
            }
        });
        return rowView;

    };
    public void updateItems(ArrayList<String> lfs) {
        this.maintitle=new ArrayList<>(lfs);
        this.notifyDataSetChanged();
    }

}