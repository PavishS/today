package com.example.foodorderingapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {
    private static final Pattern PASSWORD_PATTERN=Pattern.compile("^" +
            "(?=.*[0-9])" +         //at least 1 digit
            "(?=.*[a-z])" +         //at least 1 lower case letter
            "(?=.*[A-Z])" +         //at least 1 upper case letter
            "(?=.*[a-zA-Z])" +      //any letter
            "(?=.*[@#$%^&+=])" +    //at least 1 special character
            "(?=\\S+$)" +           //no white spaces
            ".{4,}" +               //at least 4 characters
            "$");
    private static final Pattern DOB_PATTERN=Pattern.compile("^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]|(?:Jan|Mar|May|Jul|Aug|Oct|Dec)))\\1|(?:(?:29|30)(\\/|-|\\.)" +
            "(?:0?[1,3-9]|1[0-2]|(?:Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec))\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)(?:0?2|(?:Feb))\\3" +
            "(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9]|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep))|(?:1[0-2]|(?:Oct|Nov|Dec)))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$");
    Button reg;
    EditText name,pw,dob,mno;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        reg=findViewById(R.id.Register);
        name=findViewById(R.id.regNameET);
        pw=findViewById(R.id.regPassword);
        dob=findViewById(R.id.regDOB);
        mno=findViewById(R.id.regMobile);
        sp=getSharedPreferences("Login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sp.edit();
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RegisterActivity.this,MainActivity.class);
                if (validateUsername()&&validatePassword()&&validateDOB()&&validateMobileNumber()) {
                    String nameTxt=name.getText().toString().trim();
                    String passwordTxt=pw.getText().toString().trim();
                    String dobTxt=dob.getText().toString().trim();
                    String mobTxt=mno.getText().toString().trim();
                    editor.putString(nameTxt,passwordTxt);
                    editor.putString(nameTxt+passwordTxt+"DOB",dobTxt);
                    editor.putString(nameTxt+passwordTxt+"Mob",mobTxt);
                    editor.commit();
                    startActivity(i);
                }
            }
        });
    }
    private boolean validatePassword(){
        String passwordInput=pw.getText().toString().trim();
        if (passwordInput.isEmpty()){
            pw.setError("Empty");
            return false;
        }
        else if(!PASSWORD_PATTERN.matcher(passwordInput).matches()){
            pw.setError("Weak Password");
            return false;
        }
        else{
            pw.setError(null);
            return true;
        }

    }
    private boolean validateUsername() {
        String usernameInput = name.getText().toString().trim();

        if (usernameInput.isEmpty()) {
            name.setError("Field can't be empty");
            return false;
        } else if (usernameInput.length() > 15) {
            name.setError("Username too long");
            return false;
        } else {
            name.setError(null);
            return true;
        }
    }
    private boolean validateDOB(){
        String dobInput=dob.getText().toString().trim();
        if (dobInput.isEmpty()){
            dob.setError("Date is empty");
            return false;
        }
        else if(!DOB_PATTERN.matcher(dobInput).matches()){
            dob.setError("Wrong date format");
            return false;
        }
/*        else if (under18())
        {
            dob.setError("Under 18");
            return false;
        }*/
        else {
            name.setError(null);
            return true;
        }
    }

    private boolean validateMobileNumber(){
        String mob=mno.getText().toString().trim();
        if (mob.length() != 10){
            mno.setError("Wrong Mobile Number");
            return false;
        } else{
            mno.setError(null);
            return true;
        }

    }
/*    private boolean under18() {
        String dobInput=dob.getText().toString().trim();
        String[] arr=dobInput.split("-");
        int age=getAge(Integer.parseInt(arr[2]),Integer.parseInt(arr[1]),Integer.parseInt(arr[0]));
        if (age<18){
            return true;
        }
        else{
            return false;
        }
    }*/


    private int getAge(int year, int month, int dayOfMonth) {
        GregorianCalendar cal = new GregorianCalendar();
        int y, m, d, a;

        y = cal.get(Calendar.YEAR);
        m = cal.get(Calendar.MONTH);
        d = cal.get(Calendar.DAY_OF_MONTH);
        cal.set(year, month, dayOfMonth);
        a = y - cal.get(Calendar.YEAR);
        if ((m < cal.get(Calendar.MONTH))
                || ((m == cal.get(Calendar.MONTH)) && (d < cal
                .get(Calendar.DAY_OF_MONTH)))) {
            --a;
        }
        if(a < 0)
            throw new IllegalArgumentException("Age < 0");
        return a;
    }
}