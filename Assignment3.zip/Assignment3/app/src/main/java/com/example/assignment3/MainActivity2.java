package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        rv = findViewById(R.id.rv);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                List<User> users = UserRoomDatabase.getInstance(getApplicationContext()).userDao().getAllUsers();
                rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                UserAdapter userAdapter = new UserAdapter(users);
                rv.setAdapter(userAdapter);
            }
        });
        thread.start();
    }
}