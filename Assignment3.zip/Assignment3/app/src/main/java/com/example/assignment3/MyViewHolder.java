package com.example.assignment3;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment3.R;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView uname,upass;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        uname = itemView.findViewById(R.id.tv1);
        upass = itemView.findViewById(R.id.tv2);
    }
}
